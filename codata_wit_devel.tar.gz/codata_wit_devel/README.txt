This archive contains details and pointers concerning the Isabelle development
reported in the paper:

1. Pointers to the ML code handling witnesses,
2. The derivation trees case study,
3. Sample (co)datatype declarations with computed witnesses.

The development has been integrated in the Isabelle2013-2 distribution, 
available at: 

  http://isabelle.in.tum.de

More details are given below.


1. ML code

The (co)datatype package is located in the Isabelle distribution at:
   
   src/HOL/BNF

The code handling witnesses (described in the paper's section 5) is located at

   src/HOL/BNF/Tools/bnf_def.ML               (for basic BNFs)
   src/HOL/BNF/Tools/bnf_comp.ML              (for composition)
   src/HOL/BNF/Tools/bnf_comp_tactics.ML
   src/HOL/BNF/Tools/bnf_lfp.ML               (for initial algebras / datatypes)
   src/HOL/BNF/Tools/bnf_lfp_tactics.ML
   src/HOL/BNF/Tools/bnf_gfp.ML               (for final coalgebra / codatatypes)
   src/HOL/BNF/Tools/bnf_gfp_tactics.ML

The *_tactics.ML files certify the witnesses, which are produced (as Isabelle
terms) in the other files.

A short README of the (co)datatype package can be accessed at 

    http://isabelle.in.tum.de/repos/isabelle/raw-file/Isabelle2013-2/src/HOL/BNF/README.html


2. Derivation trees

The theories are available in this archive in both pdf and html-browsable forms.

The Isabelle sources for the generated files are located in the Isabelle
distribution at

   src/HOL/BNF/Examples/Derivation_Trees

The theory DTree contains the definition of the derivation-tree codatatype.  For
convenience, it also transports the package-produced facts from the type "'a
fset" of finite sets over 'a, to the more standard (and better supported) type
"'a set" of arbitrary sets over 'a.

The theory Gram_Lang develops the theory of grammar-generated languages
discussed in the paper.  

The notations are mostly identical to the ones used in the paper, so that the
reader should be able to identify in the formal scripts the relevant
constructions and facts.


3. Sample (co)datatype declarations

The theory Sample in this archive contains the (co)datatype declarations
examplified in the paper.
